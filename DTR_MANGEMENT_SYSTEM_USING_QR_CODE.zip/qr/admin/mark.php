<?php
	date_default_timezone_set("Asia/manila");
	if (isset($_GET['id']) && !empty($_GET['id']) && isset($_GET['time']) && !empty($_GET['time'])) {
		require '../connection.php';
		$uid = $conn->real_escape_string($_GET['id']);
		$time = $conn->real_escape_string(urldecode($_GET['time']));

		$sql = "SELECT * FROM `users` WHERE `uid` = '$uid'";
		$result = $conn->query($sql);
		$details = $result->fetch_assoc();
		// if ($details['access'] == "restricted") {
		// 	echo '5'; //user restricted
		// 	return 5;
		// }
		// if ($details['access'] == "regular") {
		// 	if ((date("H:i:s", time()) < $details['start_time']) || (date("H:i:s", time()) > $details['end_time'])) {
		// 		echo '6'; //outside hours
		// 		return 6;
		// 	}
		// }
		if ($result->num_rows) {
			
				$sql = "SELECT * FROM `attendance` WHERE `uid` = '$uid' ORDER BY `aid` DESC LIMIT 1";
				$result = $conn->query($sql)->fetch_assoc();
				if (date("Y-m-d", strtotime($result['timestamp'])) == date("Y-m-d", time())) {
					if ($result['action'] == "out") {
						$aid = $result['aid'];
						$current = date("Y-m-d H:i:s", time());
						$sql = "INSERT INTO `attendance` VALUES (NULL, '$uid', 'in', '$current')";
						$conn->query($sql);
						if ($conn->affected_rows) {
							$output = array();
							$sql1 = "SELECT * FROM users u LEFT JOIN attendance a ON a.uid = u.uid WHERE a.uid = '".$uid."' AND a.timestamp = '".$current."' LIMIT 1";
							$res = $conn->query($sql1);
							$row = $res->fetch_assoc();
							    $date_time = date_create_from_format("Y-m-d H:i:s", $row['timestamp']);
								$date_time_str = date_format($date_time, "F j, Y g:i a");
								$output["NAME"] = $row['name'];
								$output["ADDRESS"] = $row['address'];
								$output["TIMEIN"] = $date_time_str;
								$output["STATUS"] = $row['action'];
	
	
							echo json_encode($output);
							//echo '2'; //attendance updated!
							//return 2;
						}
						else {
							echo '0';
							return 0;
						}
					}
					else {
						$current = date("Y-m-d H:i:s", time());
						$sql = "INSERT INTO `attendance` VALUES (NULL, '$uid', 'out', '$current')";
						if ($conn->query($sql)) {
							//echo '1';
							$output = array();
							$sql1 = "SELECT * FROM users u LEFT JOIN attendance a ON a.uid = u.uid WHERE a.uid = '".$uid."' AND a.timestamp = '".$current."' LIMIT 1";
							$res = $conn->query($sql1);
							$row = $res->fetch_assoc();
							    $date_time = date_create_from_format("Y-m-d H:i:s", $row['timestamp']);
								$date_time_str = date_format($date_time, "F j, Y g:i a");
								$output["NAME"] = $row['name'];
								$output["ADDRESS"] = $row['address'];
								$output["TIMEIN"] = $date_time_str;
								$output["STATUS"] = $row['action'];
								// $output["PHOTO"] = $row->photo;
								
	
	
							echo json_encode($output);
							//return 1;
						}
						else {
							echo '0';
							return 0;
						}
					}
				}
				else {
					$today = date("Y-m-d H:i:s", time());
					$sql = "INSERT INTO `attendance` VALUES (NULL, '$uid', 'in', '$today')";
					if ($conn->query($sql)) {
						//echo '1'; //attendance marked successfully!
						$output = array();
							$sql1 = "SELECT * FROM users u LEFT JOIN attendance a ON a.uid = u.uid WHERE a.uid = '".$uid."' AND a.timestamp = '".$current."' LIMIT 1";
							$res = $conn->query($sql1);
							$row = $res->fetch_assoc();
							    $date_time = date_create_from_format("Y-m-d H:i:s", $row['timestamp']);
								$date_time_str = date_format($date_time, "F j, Y g:i a");
								$output["NAME"] = $row['name'];
								$output["ADDRESS"] = $row['address'];
								$output["TIMEIN"] = $date_time_str;
								$output["STATUS"] = $row['action'];
	
	
							echo json_encode($output);
						//return 1;
					}
					else {
						echo '0'; //attendance not marked!
						return 0;
					}
				}
			
		}
		else {
			echo '4'; //user does not exist!
			return 4;
		}
	}
?>