<?php
	// $conn = new mysqli('<server-name>', '<username>', '<password>', '<db-name>');
	$conn = new mysqli('localhost', 'root', '', 'attendanceqr');
?>